
export function logError(message) {
  console.error("[URBZToken Error]:", message);
}
